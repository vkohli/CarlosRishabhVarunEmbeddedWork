/**
 * @file mutex.c
 *
 * @brief Implements mutices.
 *
 * @author Carlos Gil : cgil
 * @author Varun Kohli : vkohli
 * @author Rishabh Singh : rasingh
 *
 * 
 * @date  12/7/12 5:07 pm
 */

#define DEBUG_MUTEX 0

#include <lock.h>
#include <task.h>
#include <sched.h>

#include <bits/errno.h>
#include <arm/psr.h>
#include <arm/exception.h>
#ifdef DEBUG_MUTEX
#include <exports.h> // temp
#endif

mutex_t gtMutex[OS_NUM_MUTEX];

/*Initiate everything in gtMutex to zero*/
void mutex_init()
{	
  int i = 0;
  for (i = 0; i < OS_NUM_MUTEX; i++)
    {
      gtMutex[i].bAvailable = 0;
      gtMutex[i].pHolding_Tcb = 0;
      gtMutex[i].bLock = 0;
      gtMutex[i].pSleep_queue = 0;
    }
  return;
}

int mutex_create(void)
{
  /*Loop through all identifiers and finds an available mutex*/
  int i = 0;
  for (i = 0; i < OS_NUM_MUTEX; i++)
    {
      /*It's available*/
      if (gtMutex[i].bAvailable == 0)
	{
	  gtMutex[i].bAvailable = 1;
	  return i;
	}
    }
	
  /*None available, return the error*/
  return -ENOMEM;

}

/*mutex_lock
 This function checks to see if the mutex is available to lock. If it is,
 we lock it by setting the values appropriately. Else, add the task to the
 sleep queue until it is available

 returns 0 on success
 */
int mutex_lock(int mutex  __attribute__((unused)))
{

  tcb_t* current_tcb = get_cur_tcb();
  tcb_t* holding_tcb;
  tcb_t* temp_sleep;

  /*Check for Errors*/
  /*Mutex not available*/
  if (!(gtMutex[mutex].bAvailable)) 
	{
		return -EINVAL;
	}
	
  /*Mutex Out of Range Error*/
  if (!((mutex >= 0) && (mutex < OS_NUM_MUTEX)))
    {
      return -EINVAL;
    }

  /*Check if already holding task*/
  holding_tcb = gtMutex[mutex].pHolding_Tcb;
  if (current_tcb->cur_prio == holding_tcb->cur_prio)
    {
      return -EDEADLOCK;
    }

  /*If not locked then acquire it*/
  if (gtMutex[mutex].bLock == 0)
    {
      gtMutex[mutex].bLock = 1;
      current_tcb->holds_lock += 1;

      /*HLP after acquiring lock*/
      if(HLP)
	{
	  /*Escalate priority*/
	  disable_interrupts();
	  current_tcb->cur_prio = 0;
	  runqueue_add(current_tcb, 0);
	  enable_interrupts();
	}		
      gtMutex[mutex].pHolding_Tcb = current_tcb;      
    }
  else /*It's locked, set to sleep until free*/
    {
      if(gtMutex[mutex].pSleep_queue == 0)
	gtMutex[mutex].pSleep_queue = current_tcb;
      else
	{
	  temp_sleep = gtMutex[mutex].pSleep_queue;
	  while(temp_sleep->sleep_queue != 0)
	    {
	      temp_sleep = temp_sleep->sleep_queue;
	    }
	  temp_sleep->sleep_queue = current_tcb;
	}
      dispatch_sleep();
    }

  return 0; /*Return 0 on success*/
}

/* mutex_unlock
  unlocks a mutex if sleep_queue is empty, otherwise gives the Mutex to
  the next task in the sleep_queue

  returns 0 on success
*/
int mutex_unlock(int mutex  __attribute__((unused)))
{
  tcb_t* current_tcb = get_cur_tcb();

  /*Check for Errors*/
  if (!((mutex >= 0) && (mutex < OS_NUM_MUTEX)))
    {
      return -EINVAL;
    }
  /*Current task does not hold the mutex*/
  if (gtMutex[mutex].pHolding_Tcb->cur_prio != current_tcb->cur_prio) 
    {
      return -EPERM;
    }

  if(HLP)
    {
      /*remove escalated priority*/
      disable_interrupts();
      current_tcb = runqueue_remove(0);
      current_tcb->cur_prio = current_tcb->native_prio;
      enable_interrupts();
    }
	
	
  /*Give possession to next thing in sleep queue or unlock if empty*/
  if (gtMutex[mutex].pSleep_queue == 0) //Empty queue so unlock
    {
      gtMutex[mutex].bLock = 0;
      current_tcb->holds_lock -= 0;
      gtMutex[mutex].pHolding_Tcb = 0;
    }
  else /*Someone is waiting for this mutex; give it to next person in queue*/
    {
      /*Set holding tcb to be the head of whats in the sleep queue*/
      current_tcb->holds_lock = 0;
      gtMutex[mutex].pHolding_Tcb = gtMutex[mutex].pSleep_queue;
      gtMutex[mutex].pHolding_Tcb->holds_lock -= 1;
      gtMutex[mutex].pSleep_queue = gtMutex[mutex].pHolding_Tcb->sleep_queue;
      gtMutex[mutex].pHolding_Tcb->sleep_queue = 0;
      runqueue_add(gtMutex[mutex].pHolding_Tcb, gtMutex[mutex].pHolding_Tcb->cur_prio);
     
    }
	
  return 0; /*Return 0 on success*/
}

