/** @file main.c
 *
 * @brief kernel main
 *
 * @author Varun Kohli <vkohli@andrew.cmu.edu>
 *	   Rishabh Alaap Singh <rasingh@andrew.cmu.edu>
 *         Carlos Gil <cgil@cmu.edu>	   
 *
 * @date   
 */

#include <lock.h> 
#include <kernel.h>
#include <task.h>
#include <sched.h>
#include <device.h>
#include <assert.h>
#include <arm/psr.h>
#include <arm/reg.h>
#include <arm/exception.h>
#include <arm/interrupt.h>
#include <arm/timer.h>

#include <bits/swi.h>
/*==MACROS==*/
#define ERRORCONST 0x0BADC0DE
#define LDRCONST 0xE51FF004 /*Represents the instruction LDR pc, [pc, -4]*/
#define SWIADDR 0x08 /*Address of SWI in Vector Table*/
#define IRQADDR 0x18 /*Address of IRQ in Vector Table*/
/*==========*/

/*==GLOBAL VARS==*/
uint32_t global_data;

/*system_time represents the timer of
  the OS since it's booting. It is volatile as it can be changed by an 
  interrupt handler, so we cannot assume it to be a constant value. */

volatile unsigned long system_time; 

/*===============*/

/*==PROTOTYPE FUNCTIONS==*/

/*Handler Functions*/
unsigned s_handler(); 
void irq_wrapper(); 
void irq_handler();
void C_SWI_handler(unsigned swi_num, unsigned *regs);
unsigned int get_handler_addr(unsigned int swiVecAddr);
int setup_user(int argc, char *argv[]);

/*SysCall Functions*/
ssize_t read_syscall(int fd, char* buf, int count);
ssize_t write_syscall(int fd, char* buf, int count);
void sleep_syscall(unsigned long millis);
unsigned long time_syscall(void);
void invalid_syscall(unsigned int call_num  __attribute__((unused)));
int task_create(task_t* tasks __attribute__((unused)), size_t num_tasks __attribute__((unused)));
int event_wait(unsigned int dev __attribute__((unused)));

/*=======================*/

/*kmain
 *This is the kernel's main function, which comes straight from the UBoot 
 *from start.S. We install the SWI and IRQ handlers in this function, 
 *and set up the user and IRQ stacks.
 */
int kmain(int argc __attribute__((unused)), char** argv  __attribute__((unused)), uint32_t table)
{
  app_startup();
  global_data = table;
  
  /* Variables used for initializing SWIs and IRQs*/
  unsigned int swiHandAddr, irqHandAddr;
  unsigned int savedSwiOne, savedSwiTwo, savedIrqOne, savedIrqTwo;
  unsigned savedICMR, savedICLR, savedOIER;
  int exitStatus;

  
  /*==Install the Handlers==*/
  
  /*Find the addresses of the SWI and IRQ handlers as defined by
    the Gumstix*/
  swiHandAddr = get_handler_addr(SWIADDR);
  irqHandAddr = get_handler_addr(IRQADDR);
  
  /*Save the first 2 instructions of the old SWI and IRQ handlers 
    (we will be overwriting this)*/
  savedSwiOne = *(unsigned int*) swiHandAddr;
  savedSwiTwo = *(unsigned int*) (swiHandAddr+4);
  savedIrqOne = *(unsigned int*) irqHandAddr;
  savedIrqTwo = *(unsigned int*) (irqHandAddr+4);
  
  /*Push in our own s_handler and irq_handler in the positions of 
    the original handlers*/ 
  *(unsigned int *) swiHandAddr = (unsigned) LDRCONST;
  *(unsigned int *) (swiHandAddr+4) = (unsigned) &s_handler;
  *(unsigned int *) irqHandAddr = (unsigned) LDRCONST;
  *(unsigned int *) (irqHandAddr+4) = (unsigned) &irq_wrapper;
  
  /*========================*/
  
  /*Setup IRQ and OS timer registers*/
  system_time = 0;
  
  /*save current register values to restore later*/
  savedICMR = reg_read(INT_ICMR_ADDR);
  savedICLR = reg_read(INT_ICLR_ADDR);
  savedOIER = reg_read(OSTMR_OIER_ADDR);
  
  /*set ICMR, and ICLR (everythin goes to IRQ and only M0 triggers)*/
  reg_write(INT_ICMR_ADDR, 1 << INT_OSTMR_0);
  reg_write(INT_ICLR_ADDR, 0x0);
  
  /*Set the OSMR Register*/ 
  reg_clear(OSTMR_OIER_ADDR, 
	    OSTMR_OIER_E1 | OSTMR_OIER_E2 | OSTMR_OIER_E3);
  reg_set(OSTMR_OIER_ADDR, OSTMR_OIER_E0);
  reg_write(OSTMR_OSMR_ADDR(0), 
	    reg_read(OSTMR_OSCR_ADDR)+3250);

  mutex_init();

  /*Install setup user stack, irq stack, and to user mode*/
  exitStatus = setup_user(argc, argv);

  /*restore old register values*/
  reg_write(INT_ICMR_ADDR, savedICMR);
  reg_write(INT_ICLR_ADDR, savedICLR);
  reg_write(OSTMR_OIER_ADDR, savedOIER);
  
  /*restore old swiHandler, irq*/
  *(unsigned int*) swiHandAddr = savedSwiOne;
  *(unsigned int*) (swiHandAddr+4) = savedSwiTwo;
  *(unsigned int*) irqHandAddr = savedIrqOne;
  *(unsigned int*) (irqHandAddr + 4) = savedIrqTwo;
  
  return exitStatus;
  
  assert(0);        /* should never get here */
}


/*get_handler_addr
 *This function takes in a vector address (address from the vector table) and
 *returns the address location of this interrupt's handler. Used to 
 *detect the address of the SWI and IRQ handlers, that we hence use to 
 *install our own.
 */
unsigned int get_handler_addr(unsigned int VecAddr)
{
  unsigned int VecInstr;
  unsigned int registers, offset, offsetSign, opcode;
  unsigned int pc_offset = 0x8; /*offset of the program counter*/

  /*Find the Instruction code in hex*/
  VecInstr = *(unsigned int *) VecAddr;
  
  /* Note the offset mentioned in the instruction at that location*/
  offset = (VecInstr & 0xFFF);
  offsetSign = (VecInstr >> 23) & 1;
  registers = ((VecInstr >> 12) & 0xFF);

  /*opcode is storing not just the opcoe but the condition(always)
    and the load bit as well*/
  opcode = (VecInstr >> 20) & 0xFFF;
  
  /* If the registers are not pc, and the opcode does not
     have condition always, the load/str code, and 
     the load bit set, return an error.
  */
  if (registers != 0xFF || (opcode != 0xe51 && opcode != 0xe59))
    {
      printf("Unrecognized instruction: %u @ 0x08\n", VecInstr);
      return ERRORCONST;
    }

  if (!offset) offset = offset*(-1);

  /* return the  address of the respective handler */
  return *(unsigned int *)(offset+VecAddr+pc_offset);
}

/* C_SWI_handler
 * dispatches swi to appropriate sys_calls
 */
void C_SWI_handler(unsigned swi_num, unsigned *regs)
{
  char* buf;
  int fd;
  int count;
  int dev;
  int mutex;
  unsigned long millis;
  task_t* tasks;
  unsigned int num_tasks;

  switch(swi_num) {
    
    /*Read Syscall, check for errors, else call the helper*/
  case READ_SWI:
    fd = regs[0];
    buf = (char *) regs[1];
    count = regs[2];
    regs[0] = read_syscall(fd, buf, count);
    break;
    
    /*Write Syscall, check for errors else call the helper */
  case WRITE_SWI:
    fd = regs[0];
    buf = (char *) regs[1];
    count = regs[2];    
    regs[0] = write_syscall(fd, buf, count);
    break;

    /*Time Syscall*/
  case TIME_SWI:
    regs[0] = time_syscall();
    break;

    /*Sleep Syscall*/
  case SLEEP_SWI:
    millis = regs[0];
    sleep_syscall(millis);
    break;

  case CREATE_SWI:
    tasks = (task_t *) regs[0];
    num_tasks = regs[1];
    regs[0] = task_create(tasks, num_tasks);
    break;
    
  case MUTEX_CREATE:
    regs[0] = mutex_create();
    break;
    
  case MUTEX_LOCK:
    mutex = regs[0];
    regs[0] = mutex_lock(mutex);
    break;
    
  case MUTEX_UNLOCK:
    mutex = regs[0];
    regs[0] = mutex_unlock(mutex);
    break;

  case EVENT_WAIT:
    dev = regs[0];
    regs[0] = event_wait(dev);
    break;

  default:
    printf("swi_num: %x\n", swi_num);
    invalid_syscall(ERRORCONST);
  }
  return;
}

/*irq_handler
 *the IRQ interrupt handler contains the implementation of kernel whenever an 
 *IRQ is called. Since in our implementation the IRQ handler is called every
 *millisecond, we will be incrementing the global var 'system_time' and 
 *incrementing the OSMR to the next 10th millisecond. 
 */
void irq_handler()
{
  /*Notes and Assumptions:
    - The clock speed is 3.25 MHz. Hence, timer resolution of 10 milliseconds 
    is represented by 32500 clock cycles
  */
  //only do it if interrupt is set and for a correct (m0) timer interrupt
  if(reg_read(OSTMR_OSSR_ADDR) & OSTMR_OSSR_M0
     && reg_read(INT_ICPR_ADDR) >> INT_OSTMR_0)
    {
      while(reg_read(OSTMR_OSMR_ADDR(0)) < reg_read(OSTMR_OSCR_ADDR)){
      /*Increment the time as this is executed every 10th  millisecond*/
	system_time += 10;
      
	/*Set OSMR to the next 10th millisecond value*/
	reg_write(OSTMR_OSMR_ADDR(0), 
		  reg_read(OSTMR_OSMR_ADDR(0))+32500);
      }
      /*disable the interrupt by placing 1 into OSSR*/
      reg_set(OSTMR_OSSR_ADDR, OSTMR_OSSR_M0);
    }
  dev_update(system_time);
  return;
}
