/** @file io.c
 *
 * @brief Kernel I/O syscall implementations
 *
 * @author Mike Kasick <mkasick@andrew.cmu.edu>
 * @date   Sun, 14 Oct 2007 00:07:38 -0400
 *
 * @author Kartik Subramanian <ksubrama@andrew.cmu.edu>
 * @date   2008-11-16
 */

#include <types.h>
#include <bits/errno.h>
#include <bits/fileno.h>
#include <arm/physmem.h>
#include <syscall.h>
#include <exports.h>
#include <kernel.h>

/* Macros for special chars and Memory Bounds*/
#define EOT_CHAR 0x04
#define DEL_CHAR 0x7f
#define SDRAMLOW 0xA0000000
#define SDRAMHIGH 0xA3FFFFFF
#define ROMLOW 0x0
#define ROMHIGH 0xFFFFFF

/* Read count bytes (or less) from fd into the buffer buf. */
ssize_t read_syscall(int fd __attribute__((unused)), void *buf __attribute__((unused)), size_t count __attribute__((unused)))
{
  unsigned int bytesRead = 0;
  char charRead;
  char tempBuf[count];

  /* check for errors */
  if (fd != STDIN_FILENO)
    {
      return -EBADF;
    }
  else if((unsigned) &buf < (unsigned) SDRAMLOW ||
	  (unsigned) &buf+count > (unsigned) SDRAMHIGH)
    {
      return -EFAULT;
    }

  /* Start the read */
  while (bytesRead < count) 
    {
      charRead = getc();
      /*EOT*/
      if (charRead == EOT_CHAR)
	return bytesRead;
      /*backspace or delete*/
      else if(charRead == 8 || charRead == DEL_CHAR)
	{
	  bytesRead--;
	  puts("\b \b");
	}
      /*carriage return or newline*/
      else if(charRead == 10 || charRead == 13)
	{
	  tempBuf[bytesRead] = '\n';
	  bytesRead++;
	  putc('\n');
	  return bytesRead;
	}
      else
	{
	  tempBuf[bytesRead] = charRead;
	  bytesRead++;
	  putc(charRead);
	}
    }
  buf = tempBuf;
  return bytesRead;	
}

/* Write count bytes to fd from the buffer buf. */
ssize_t write_syscall(int fd  __attribute__((unused)), const void *buf  __attribute__((unused)), size_t count  __attribute__((unused)))
{
  unsigned int byteWritten = 0;
  char* tempBuf = (char *) buf;
  if (fd != STDOUT_FILENO)
    {
      return -EBADF;
    }
  else if(!(((unsigned)&buf >= (unsigned)SDRAMLOW && 
	    (unsigned) &buf+count < (unsigned) SDRAMHIGH) ||
	    ((unsigned) &buf+count < (unsigned) ROMHIGH)))
    {
      return -EFAULT;
    }
  
  while(byteWritten < count) 
    {
      if(tempBuf[byteWritten] == '\0')
	return byteWritten;
      else
	{
	  putc(tempBuf[byteWritten]);
	  byteWritten++;
	}
    }
  return byteWritten;	
}

