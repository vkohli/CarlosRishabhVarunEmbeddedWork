/** @file proc.c
 * 
 * @brief Implementation of `process' syscalls
 *
 * @author Mike Kasick <mkasick@andrew.cmu.edu>
 * @date   Sun, 14 Oct 2007 00:07:38 -0400
 *
 * @author Kartik Subramanian <ksubrama@andrew.cmu.edu>
 * @date 2008-11-12
 */

#include <exports.h>
#include <bits/errno.h>
#include <config.h>
#include <kernel.h>
#include <syscall.h>
#include <sched.h>

#include <arm/reg.h>
#include <arm/psr.h>
#include <arm/exception.h>
#include <arm/physmem.h>
#include <device.h>

//wasn't given in errno
#define EHOLDSLOCK 100

int task_create(task_t* tasks  __attribute__((unused)), size_t num_tasks  __attribute__((unused)))
{
  unsigned int  i, j, k;
  int switched;
  task_t temp;

  if (tasks == 0) return -ESCHED;
  if (num_tasks > 62) return -EINVAL;

  //test for errors
  for (i = 0; i < num_tasks; i++) 
    {
      if (tasks[i].lambda == 0) return -ESCHED;
      if (tasks[i].stack_pos == 0) return -ESCHED;
      if (tasks[i].C <= 0) return -ESCHED;
      if (tasks[i].T <= 0) return -ESCHED;
      if (tasks[i].C > tasks[i].T) return -ESCHED;
    }
  //bubble sort, sort tasks by C, from lowest to highest
  for (j = 0; j < num_tasks; j++)
    {
      switched = 0;
      for(k = 0; k < num_tasks-1; k++)
	{
	  if (tasks[k].C > tasks[k+1].C) 
	    {
	      temp = tasks[k+1];
	      tasks[k+1] = tasks[k];
	      tasks[k] = temp;
	      switched = 1;
	    }
	}
      if(!switched) break;
    }
  //returns if the tasks are not schedulable
  allocate_tasks(&tasks, num_tasks);
  
  //tests ub_test (infinite loops upon failure)
  if(!assign_schedule(&tasks,num_tasks)) return -ESCHED;
  
  dispatch_nosave();

  enable_interrupts();
  
  return 0;
}

int event_wait(unsigned int dev  __attribute__((unused)))
{
  if (dev > 3) return -EINVAL;
  
  //if something with prio of 0, return EHOLDSLOCK
  if (get_cur_tcb()->holds_lock && !get_cur_tcb()->cur_prio) 
    return -EHOLDSLOCK;
  dev_wait(dev);
  //should not get here
  return 0; 	
}

/* An invalid syscall causes the kernel to exit. */
void invalid_syscall(unsigned int call_num  __attribute__((unused)))
{
	printf("Kernel panic: invalid syscall -- 0x%08x\n", call_num);

	disable_interrupts();
	while(1);
}
