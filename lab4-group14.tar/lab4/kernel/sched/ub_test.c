/** @file ub_test.c
 * 
 * @brief The UB Test for basic schedulability
 *
 * @author Kartik Subramanian <ksubrama@andrew.cmu.edu>
 * @date 2008-11-20
 */

//#define DEBUG 0

#include <sched.h>
#ifdef DEBUG
#include <exports.h>
#endif

 
/**
 * @brief Perform UB Test and reorder the task list.
 *
 * The task list at the end of this method will be sorted in order is priority
 * -- from highest priority (lowest priority number) to lowest priority
 * (highest priority number).
 *
 * @param tasks  An array of task pointers containing the task set to schedule.
 * @param num_tasks  The number of tasks in the array.
 *
 * @return 0  The test failed.
 * @return 1  Test succeeded.  The tasks are now in order.
 */
int assign_schedule(task_t** tasks  __attribute__((unused)), size_t num_tasks  __attribute__((unused)))
{
  unsigned long u[12];
  unsigned long uk;
  unsigned long time;
  unsigned int i;
  int cTotal;
  
  //look up table for various k values
  u[0] = 0;
  u[1] = 1;
  u[2] = 0.8284;
  u[3] = 0.7798;
  u[4] = 0.7568;
  u[5] = 0.7535;
  u[6] = 0.7348;
  u[7] = 0.7286;
  u[8] = 0.7241;
  u[9] = 0.7205;
  u[10] = 0.7177;
  u[11] = 0.71546;
  u[12] = 0.7136;
  u[13] = 0.7120;
  
  if (num_tasks == 0) return 0;
  else if (num_tasks < 14) uk = u[num_tasks];
  else uk = .69;
  
  cTotal = 0;
  time = 0;
  for (i = 0; i < num_tasks; i++)
    {
      time = (tasks[i]->C + tasks[i]->B)/tasks[i]->T;
      time += cTotal;
      if(uk > time) return 0;
      else cTotal += tasks[i]->C/tasks[i]->T;
    }
  
  return 1;
}
	


